$(document).ready(function() {
	// check if there is an error message attribute in the request
	

});